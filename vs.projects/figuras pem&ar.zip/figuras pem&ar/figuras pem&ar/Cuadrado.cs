﻿class Cuadrado : Figura
{
    public double Lado { get; set; }

    public Cuadrado(double lado)
    {
        Lado = lado;
    }

    public override double CalcularPerimetro()
    {
        return 4 * Lado;
    }

    public override double CalcularArea()
    {
        return Lado * Lado;
    }
}