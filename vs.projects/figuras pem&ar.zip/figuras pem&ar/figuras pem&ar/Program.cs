﻿using System;

abstract class Figura
{
    public abstract double CalcularPerimetro();
    public abstract double CalcularArea();
}

class Program
{
    static void Main()
    {
        Console.WriteLine("Seleccione la figura: \n1. Cuadrado \n2. Triángulo");
        int opcion = int.Parse(Console.ReadLine());

        Figura figura = null;

        switch (opcion)
        {
            case 1:
                Console.Write("Ingrese el lado del cuadrado: ");
                double ladoCuadrado = double.Parse(Console.ReadLine());
                figura = new Cuadrado(ladoCuadrado);
                break;

            case 2:
                Console.Write("Ingrese el primer lado del triángulo: ");
                double lado1 = double.Parse(Console.ReadLine());
                Console.Write("Ingrese el segundo lado del triángulo: ");
                double lado2 = double.Parse(Console.ReadLine());
                Console.Write("Ingrese el tercer lado del triángulo: ");
                double lado3 = double.Parse(Console.ReadLine());
                figura = new Triangulo(lado1, lado2, lado3);
                break;

            default:
                Console.WriteLine("Opción no válida.");
                return;
        }

        Console.WriteLine($"Perímetro: {figura.CalcularPerimetro()}");
        Console.WriteLine($"Área: {figura.CalcularArea()}");
    }
}